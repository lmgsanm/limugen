#!/usr/bin/env python3

import os
import sys
import yaml
#from yaml import load, dump
#try:
#    from yaml import CLoader as Loader,CDumper as Dumper
#except ImportError:
#    from yaml import Loader, Dumper

def get_yml_of_config(filename):
    with open(filename,'r') as f:
        stream = f.read()
    data = yaml.load(stream)
    return data
yml_of_config_file_path = "conf/config.yml"
yml_of_connection_file_path = "conf/connection.yml"
yml_of_path_file_path = "conf/path.yml"

#config_data = get_yml_of_config(yml_of_config_file_path)
#connection_data = get_yml_of_config(yml_of_connection_file_path)
#paht_data = get_yml_of_config(yml_of_path_file_path)
#
#print(config_data)
#print(connection_data)
#print(paht_data)

